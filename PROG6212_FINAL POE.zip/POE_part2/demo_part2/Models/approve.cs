﻿using System.Collections;

namespace POE_part2.Models
{
    public class approve
    {
        
    }
}
